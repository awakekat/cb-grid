# cb-grid
CodeBuddies CSS Grid Project - January 2018

Image to go by:
https://s3.envato.com/files/238572695/preview/01_home.jpg

Image info: 
- 1170px Grid System
- Fontawesome icon, FlatIcon

Fonts Used:
- Open Sans, Playfair Display

Images Used:
- www.allfreephotos.net
